#!/bin/bash

ROLE_FILE="data/role-name.txt"
TRUST_POLICY_FILE="trust-policy.json"
IAM_FILE="data/iam.txt"

# Read the role name from the file
if [ ! -f "$ROLE_FILE" ]; then
    echo "Error: Role name file $ROLE_FILE not found."
    exit 1
fi

ROLE_NAME=$(cat "$ROLE_FILE")

# Create the trust policy JSON file
cat > $TRUST_POLICY_FILE <<EOL
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "Service": "lambda.amazonaws.com"
      },
      "Action": "sts:AssumeRole"
    }
  ]
}
EOL

# Create the IAM role
echo "Creating IAM role: $ROLE_NAME"
aws iam create-role \
    --role-name $ROLE_NAME \
    --assume-role-policy-document file://$TRUST_POLICY_FILE > /dev/null 2>&1

# Attach the AWSLambdaBasicExecutionRole policy to the role
echo "Attaching AWSLambdaBasicExecutionRole policy to $ROLE_NAME"
aws iam attach-role-policy \
    --role-name $ROLE_NAME \
    --policy-arn arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole

# Clean up the trust policy file
rm $TRUST_POLICY_FILE

# Ensure $IAM_FILE is cleared at the start
> $IAM_FILE

# Store the IAM role ARN into data/iam.txt
ROLE_ARN=$(aws iam get-role --role-name $ROLE_NAME --query "Role.Arn" --output text)
echo "Storing IAM role ARN into $IAM_FILE"
echo "$ROLE_ARN" > $IAM_FILE

echo "IAM role $ROLE_NAME created successfully and stored in $IAM_FILE."