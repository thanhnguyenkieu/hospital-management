#!/bin/bash

layer_data_file="data/layers.txt"
functions_file="data/functions.txt"
iam_file="data/iam.txt"

# Check if $layer_data_file and $verions_file and $iam_file exist
if [ ! -f $layer_data_file ] || [ ! -f $verions_file ] || [ ! -f $iam_file ] || [ ! -f $functions_file ]; then
    echo "Error: $layer_data_file or $verions_file or $iam_file or $functions_file not found."
    exit 1
fi

# Read layers, functions and iam_arn from the respective files
IFS=',' read -r -a layers <<< "$(cat $layer_data_file)"
IFS=',' read -r -a functions <<< "$(cat $functions_file)"
iam_arn=$(cat $iam_file)

# Function to create a Lambda function
create_function() {
    function_name=$1
    zip_file=$2
    handler=$3

    role_arn=$iam_arn

    runtime="python3.12"
    description="Lambda function for $function_name"

    # Construct the layers array dynamically
    layers_arns=()
    for i in "${!layers[@]}"; do
        layer_name="${layers[$i]}-layer"

        # Retrieve the latest layer ARN using AWS CLI
        layer_arn=$(aws lambda list-layer-versions \
            --layer-name "$layer_name" \
            --query "LayerVersions[0].LayerVersionArn" \
            --output text)

        if [ "$layer_arn" == "None" ]; then
            echo "Error: No versions found for layer $layer_name."
            exit 1
        fi

        echo "Layer ARN for $layer_name: $layer_arn"

        layers_arns+=("$layer_arn")
    done

    echo "Create Lambda function: $function_name with zip file $zip_file"

    aws lambda create-function \
        --function-name $function_name \
        --runtime $runtime \
        --role $role_arn \
        --handler $handler \
        --zip-file fileb://$zip_file \
        --layers ${layers_arns[@]} \
        --description "$description" > /dev/null 2>&1

    echo "Function $function_name created successfully."
}

# Process each function
for function in "${functions[@]}"; do
    function_name="${function}-function"
    handler="${function}.lambda_handler"
    zip_file="zip/${function}-function.zip"

    echo "Processing function: $function_name with zip file $zip_file"

    # Check if the zip file exists
    if [ -f "$zip_file" ]; then
        create_function $function_name $zip_file $handler
    else
        echo "Warning: Zip file $zip_file not found. Skipping function $function_name."
    fi
done

echo "All functions created successfully."