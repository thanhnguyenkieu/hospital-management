#!bin/bash

functions_file="data/functions.txt"

# Check if $functions_file exists
if [ ! -f $functions_file ]; then
    echo "Error: $functions_file not found."
    exit 1
fi

# Read functions from $functions_file
IFS=',' read -r -a functions <<< "$(cat $functions_file)"

# Function to delete a Lambda function
delete_function() {
    function_name=$1

    echo "Deleting Lambda function: $function_name"

    aws lambda delete-function --function-name $function_name

    echo "Function $function_name deleted successfully."
}

# Delete Lambda functions
for function in "${functions[@]}"; do
    function_name="${function}-function"

    delete_function "$function_name"
done

echo "All specified Lambda functions deleted successfully."