#!/bin/bash

verions_file="data/versions.txt"
layer_data_file="data/layers.txt"

# Check if $layer_data_file and $verions_file exist
if [ ! -f $layer_data_file ] || [ ! -f $verions_file ]; then
    echo "Error: $layer_data_file or $verions_file not found."
    exit 1
fi

# Read layers and versions from files
IFS=',' read -r -a layers <<< "$(cat $layer_data_file)"
IFS=',' read -r -a versions <<< "$(cat $verions_file)"

# Ensure the number of layers and versions match
if [ ${#layers[@]} -ne ${#versions[@]} ]; then
    echo "Error: The number of layers and versions do not match."
    exit 1
fi

# Function to delete a layer version
delete_layer() {
    layer_name=$1
    version_number=$2

    echo "Deleting layer version $version_number of $layer_name..."

    aws lambda delete-layer-version \
        --layer-name $layer_name \
        --version-number $version_number

    echo "Layer version $version_number of $layer_name deleted successfully."
}

# Loop through layers and versions
for i in "${!layers[@]}"; do
    layer_name="${layers[$i]}-layer"
    delete_layer $layer_name "${versions[$i]}"
done

echo "All specified layer versions have been deleted."