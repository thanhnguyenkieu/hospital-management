#!/bin/bash

functions_file="data/functions.txt"

# Check if $functions_file exists
if [ ! -f $functions_file ]; then
    echo "Error: $functions_file not found."
    exit 1
fi

# Check if the zip directory exists, if not create it
if [ ! -d "zip" ]; then
    echo "Creating zip directory..."
    mkdir zip
fi

# Read function_names from $functions_file
IFS=',' read -r -a function_names <<< "$(cat $functions_file)"


# Function to create a Lambda Function zip file
create_function_zip() {
    function_zip=$1
    path_to_function=$2

    # Check zip file existence, if it exists, remove it
    if [ -f "$function_zip" ]; then
        echo "Removing existing zip file: $function_zip"
        rm -fv "$function_zip" > /dev/null 2>&1
    fi

    echo "Creating zip file for function: $function_zip from $path_to_function"

    # Save the current directory
    current_dir=$(pwd)

    # Dynamically determine the parent directory and zip the contents
    (cd $path_to_function && zip -r "${current_dir}/${function_zip}" . > /dev/null 2>&1)

    # Return to the original directory
    cd $current_dir
}


# Loop through function_names and create zip files
for function_name in "${function_names[@]}"; do
    function_zip="zip/${function_name}-function.zip"
    path_to_function="src/${function_name}"

    create_function_zip $function_zip $path_to_function
done

echo "All layer zip files created successfully."