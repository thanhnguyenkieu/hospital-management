import numpy as np
import humanize


def lambda_handler(event, context):
    array = np.array([1, 2, 3])
    number = humanize.intword(12000000000000000)

    return {
        'statusCode': 200,
        'body': {
            'shape': array.shape,
            'number': number
        }
    }
