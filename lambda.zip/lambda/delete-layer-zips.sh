#!/bin/bash

summary_file="data/summary.txt"
layer_data_file="data/layers.txt"

# Check if $layer_data_file exists
if [ ! -f $layer_data_file ]; then
    echo "Error: $layer_data_file not found."
    exit 1
fi

# Read layer_names from $layer_data_file
IFS=',' read -r -a layer_names <<< "$(cat $layer_data_file)"

# Function to delete a zip file
delete_zip_file() {
    zip_file=$1

    # Check if the zip file exists
    if [ -f "$zip_file" ]; then
        echo "Deleting zip file: $zip_file"
        rm -v "$zip_file"
        echo "Zip file $zip_file deleted successfully."
    else
        echo "Warning: Zip file $zip_file not found. Skipping deletion."
    fi
}

# Delete zip files for each layer
for layer_name in "${layer_names[@]}"; do
    zip_file="zip/${layer_name}-layer.zip"
    delete_zip_file "$zip_file"
done

# Check and delete $summary_file if it exists
if [ -f $summary_file ]; then
    echo "Deleting $summary_file"
    rm -v $summary_file
else
    echo "Warning: $summary_file not found. Skipping deletion."
fi

echo "All zip files deleted successfully."