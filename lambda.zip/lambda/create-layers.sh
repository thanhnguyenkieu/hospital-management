#!/bin/bash

verions_file="data/versions.txt"
layer_data_file="data/layers.txt"

# Function to publish a Lambda layer
publish_layer() {
    layer_name=$1
    zip_file=$2

    echo "Publishing layer: $layer_name with zip file $zip_file"

    # Publish the layer and capture the output
    output=$(aws lambda publish-layer-version \
        --layer-name $layer_name \
        --zip-file fileb://$zip_file \
        --compatible-runtimes python3.12 \
        --description "Layer for $layer_name")

    # Extract the version from the output using jq
    version=$(echo "$output" | jq -r '.Version')

    # Append the version to the versions array
    versions+=("$version")
}

# Ensure $verions_file is cleared at the start
> $verions_file

# Initialize an array to store versions
versions=()

# Read the single line from $layer_data_file and split it by commas
IFS=',' read -r -a layers <<< "$(cat $layer_data_file)"

# Process each layer
for layer in "${layers[@]}"; do
    layer_name="${layer}-layer"
    zip_file="zip/${layer}-layer.zip"

    echo "Processing layer: $layer_name"
    echo "Zip file: $zip_file"

    # Check if the zip file exists
    if [ -f "$zip_file" ]; then
        publish_layer "$layer_name" "$zip_file"
    else
        echo "Warning: Zip file $zip_file not found. Skipping layer $layer_name."
    fi
done

# Write all versions to $verions_file, comma-separated
IFS=',' # Set the delimiter to comma
echo "${versions[*]}" > $verions_file

echo "All layers published successfully. Versions saved to $verions_file."