#!/bin/bash

summary_file="data/summary.txt"
layer_data_file="data/layers.txt"

# Check if $layer_data_file exists
if [ ! -f $layer_data_file ]; then
    echo "Error: $layer_data_file not found."
    exit 1
fi

# Check if the zip directory exists, if not create it
if [ ! -d "zip" ]; then
    echo "Creating zip directory..."
    mkdir zip
fi

# Read layer_names from $layer_data_file
IFS=',' read -r -a layer_names <<< "$(cat $layer_data_file)"

# Ensure the $summary_file file is empty before starting
> $summary_file

# Function to create a Lambda layer zip file
create_layer_zip() {
    layer_zip=$1
    requirements_file=$2
    summary_file=$3

    echo "Creating zip file for layer: $layer_zip with requirements from $requirements_file"

    # Check zip file existence, if it exists, remove it
    if [ -f "$layer_zip" ]; then
        echo "Removing existing zip file: $layer_zip"
        rm -fv "$layer_zip" > /dev/null 2>&1
    fi

    # Remove the "python" directory if it exists
    if [ -d "python" ]; then
        echo "Removing existing python directory..."
        rm -rfv python > /dev/null 2>&1
    fi

    # Create the python directory
    echo "Creating python directory..."
    mkdir python

    # Install the requirements into the python directory
    echo "Installing requirements from $requirements_file..."
    pip install -r "$requirements_file" -t python/ > /dev/null 2>&1

    # Package the contents of the python directory into a zip file
    echo "Creating zip file $layer_zip..."
    zip -r "${layer_zip}" python > /dev/null 2>&1

    # Write the size of the "python" directory to $summary_file
    echo "Size of 'python' directory for $layer_zip before zip: $(du -sh python | awk '{print $1}')" >> $summary_file

    # Clean up the python directory
    echo "Cleaning up..."
    rm -rfv python > /dev/null 2>&1

    echo "Zip file $layer_name created successfully."
}


# Loop through layer_names and create zip files
for layer_name in "${layer_names[@]}"; do
    layer_zip="zip/${layer_name}-layer.zip"
    requirements_file="data/requirements-${layer_name}.txt"

    # Check if the requirements file exists
    if [ -f "$requirements_file" ]; then
        create_layer_zip "$layer_zip" "$requirements_file" $summary_file
    else
        echo "Warning: Requirements file $requirements_file not found. Skipping layer $layer_zip."
    fi
done

echo "All layer zip files created successfully."