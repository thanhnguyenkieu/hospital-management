#!/bin/bash

# Get the list of all Lambda layers in the account
aws lambda list-layers --query "Layers[*].LayerName"