#!/bin/bash

IAM_FILE="data/iam.txt"
ROLE_FILE="data/role-name.txt"

# Read the role name from the file
if [ ! -f "$ROLE_FILE" ]; then
    echo "Error: Role name file $ROLE_FILE not found."
    exit 1
fi

ROLE_NAME=$(cat "$ROLE_FILE")

# Detach all policies attached to the role
echo "Detaching policies from role: $ROLE_NAME"
attached_policies=$(aws iam list-attached-role-policies --role-name $ROLE_NAME --query "AttachedPolicies[].PolicyArn" --output text)

for policy_arn in $attached_policies; do
    echo "Detaching policy: $policy_arn"
    aws iam detach-role-policy --role-name $ROLE_NAME --policy-arn $policy_arn
done

# Delete the IAM file
rm -f $IAM_FILE

# Delete the role
echo "Deleting IAM role: $ROLE_NAME"
aws iam delete-role --role-name $ROLE_NAME

echo "IAM role $ROLE_NAME deleted successfully."