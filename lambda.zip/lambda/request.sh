#!/bin/bash

functions_file="data/functions.txt"

# Check if the functions file exists
if [ ! -f "$functions_file" ]; then
    echo "Error: $functions_file not found."
    exit 1
fi

# Read function names from the file
IFS=',' read -r -a functions <<< "$(cat $functions_file)"

# # Check if the response directory exists, if not create it
# if [ ! -d "response" ]; then
#     echo "Creating response directory..."
#     mkdir response
# fi

# Loop through each function name and invoke it
for function in "${functions[@]}"; do
    function_name="${function}-function"
    echo "Requesting Lambda function: $function_name"

    aws lambda invoke \
        --function-name "$function_name" \
        --payload '{}' \
        --cli-binary-format raw-in-base64-out \
        /dev/stdout
        # response/$function_name.json

    echo -e "\n"
done